﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Untitled Document</title>
</head>

<body>
<div class="about_body">	
		<div class="menu_title">
		  <h6>منوی اصلی </h6>
		</div><div class="text">		
		<ul>
				<li><a href="../cat/index.php" title="">مدیریت دسته ها </a></li>
				<li><a href="../product/" title="">مدیریت کالا ها </a></li>
				<li><a href="../users/index.php" title="">مدیریت کاربران </a></li>
				<li><a href="../orders/index.php" title="">سفارشات </a></li>
				<li><a href="../report/index.php" title="">گزارشات </a></li>
		</ul>
		</div>
		</div>
</body>
</html>
